package com.hsbc.banking.day20thymeleafdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day20thymeleafdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day20thymeleafdemoApplication.class, args);
	}

}
