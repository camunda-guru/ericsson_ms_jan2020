package com.ericsson.customerserviceapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerserviceappApplicationTests {

	@Test
	void contextLoads() {
	}

}
