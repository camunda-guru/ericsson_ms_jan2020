package com.ericsson.customerserviceapp.controllers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ericsson.customerserviceapp.models.Customer;
import com.ericsson.customerserviceapp.services.CustomerService;

import io.micrometer.core.ipc.http.HttpSender.Response;
import net.minidev.json.JSONObject;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;



@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CustomerController {
    @Autowired
	private CustomerService customerService;
    @CrossOrigin(origins = {"http://localhost:7070", "http://localhost:8787"}, allowedHeaders = "*",methods = {RequestMethod.GET,RequestMethod.POST})
    @PostMapping("/addcustomer")
    public @ResponseBody Customer addCustomer(@RequestBody Customer customer)
    {
    	return customerService.saveCustomer(customer);
    }
	
	  @CrossOrigin("*")
	  
	@GetMapping("/getallcustomers")
	public List<Customer> getAllCustomers() {
		return customerService.findAllCustomersInfo();
	}
	
	@CrossOrigin("*")
    @GetMapping("/getcustomerbyid/{adharCardNo}")
    public ResponseEntity<?> getCustomerById(@PathVariable("adharCardNo") long adharCardNo)
    {
		Customer customer=customerService.findByCustomerId(adharCardNo);
		if(customer!=null)
		{
			EntityModel<Customer> resource= new EntityModel<Customer>(customer);
		
			WebMvcLinkBuilder linkTo = WebMvcLinkBuilder
                .linkTo(WebMvcLinkBuilder.methodOn(this.getClass())
                .getAllCustomers());
		
		resource.add(linkTo.withRel("all-users"));
		return new ResponseEntity<>(resource,HttpStatus.OK);
		}
		else
		{
			 
		       
		            JSONObject entity = new JSONObject();
		            entity.put("msg", "No Record Found");
		           
		        
			
			return new ResponseEntity<>(entity, HttpStatus.OK);
		}
    	
    }
	//http://localhost:7070/listPageable?page=0&size=1&sort=lastName
	@GetMapping("/listPageable")
	Page<Customer> customersPageable(Pageable pageable) {
		return customerService.findAllCustomers(pageable);

	}
    
	
}
