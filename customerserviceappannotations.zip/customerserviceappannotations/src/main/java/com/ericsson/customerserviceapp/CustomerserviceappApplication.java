package com.ericsson.customerserviceapp;

import java.util.Arrays;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class CustomerserviceappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerserviceappApplication.class, args);
	}
	
	@Bean

    CommandLineRunner commandLineRunner() {
		//args data type is string[]
        return args -> 
          System.out.println("CommandLineRunner with args:"
            + Arrays.toString(args));
    }
  
    @Bean

    ApplicationRunner applicationRunner() {
    	//args data type is application arguments
        return args -> 
          System.out.println("ApplicationRunner with args:"
            + Arrays.toString(args.getSourceArgs()));
    }

}
