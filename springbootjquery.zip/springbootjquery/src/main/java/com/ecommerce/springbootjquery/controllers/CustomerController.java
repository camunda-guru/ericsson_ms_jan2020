package com.ecommerce.springbootjquery.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.springbootjquery.models.Customer;
import com.ecommerce.springbootjquery.services.CustomerService;
@Controller
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@GetMapping("/home")
	public String loadHome()
	{
		return "index";
	}
	
	@PostMapping("/getcustomerbyid") 
	public @ResponseBody Customer
	 findByCustomerId(@RequestBody Customer customer) {
		return 	customerService.getCustomerById(customer.getCustomerId());
		
	}
	
	
	/*
	 * @CrossOrigin("*")
	 * 
	 * @PostMapping("/addcustomer") public @ResponseBody Customer
	 * addCustomer(@RequestBody Customer customer) { return
	 * customerService.saveCustomer(customer); }
	 * 
	 * @CrossOrigin("*")
	 * 
	 * @GetMapping("/getcustomers") public @ResponseBody List<Customer>
	 * findAllCustomers() { return customerService.getAllCustomers(); }
	 * 
	 * @CrossOrigin("*")
	 * 
	 * @GetMapping("/getcustomerbyid/{customerId}") public @ResponseBody Customer
	 * findByCustomerId(@PathVariable("customerId") int customerId) { return
	 * customerService.getCustomerById(customerId); }
	 */
	
	
	
}
