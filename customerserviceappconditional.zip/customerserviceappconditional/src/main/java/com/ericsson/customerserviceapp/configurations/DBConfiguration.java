package com.ericsson.customerserviceapp.configurations;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
@Getter
@Setter
public class DBConfiguration {
	
	@Value("${datasource_url}")
	private String url;
	@Value("${datasource_username}")
	private String userName;
	@Value("${datasource_password}")
	private String password;
	@Value("${datasource_driver}")
	private String driver;	
	@Bean
	@ConditionalOnClass(DataSource.class)
	public DataSource createDataSource()
	{
		DataSourceBuilder builder= DataSourceBuilder.create();
		builder.url(url);
		builder.username(userName);
		builder.password(password);
		builder.driverClassName(driver);
		return builder.build();	
	}

}
