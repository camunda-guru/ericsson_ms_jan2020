package com.ericsson.orderserviceapp.services;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.json.JsonParser;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ericsson.orderserviceapp.models.Order;
import com.ericsson.orderserviceapp.repositories.OrderRepository;


@Service
public class OrderService {
	@Autowired
	private OrderRepository orderRepo;
	@Value("${customer_service_url}")
	private String customerServiceUrl;
	@Autowired
	private RestTemplate restTemplate;
	

	public Order addOrder(Order order, long customerId)
	{
		
		//inter service communication
		ResponseEntity<String> response = 
				restTemplate.exchange(customerServiceUrl+"/"+customerId,HttpMethod.GET,null,String.class);
		System.out.println(response.getBody());
		JsonParser springParser = JsonParserFactory.getJsonParser();
		Map<String, Object> map = springParser.parseMap(response.getBody());

		String mapArray[] = new String[map.size()];
		System.out.println("Items found: " + mapArray.length);
		if(map.containsKey("adharCardNo"))
		{
			System.out.println(map.get("adharCardNo"));
            order.setCustomerId(Long.parseLong(map.get("adharCardNo").toString()));
            orderRepo.save(order);
            return order;
		}
		else
			return null;
		
		
	}
}
