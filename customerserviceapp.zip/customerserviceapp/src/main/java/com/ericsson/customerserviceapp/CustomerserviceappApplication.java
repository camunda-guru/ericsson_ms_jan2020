package com.ericsson.customerserviceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerserviceappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerserviceappApplication.class, args);
	}

}
