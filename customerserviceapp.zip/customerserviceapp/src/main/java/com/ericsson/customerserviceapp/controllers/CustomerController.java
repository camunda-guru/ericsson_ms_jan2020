package com.ericsson.customerserviceapp.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParser;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ericsson.customerserviceapp.models.Customer;
import com.ericsson.customerserviceapp.services.CustomerService;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import net.minidev.json.JSONArray;

@RestController
public class CustomerController {
    @Autowired
	private CustomerService customerService;
	@CrossOrigin("*")
	//@CrossOrigin(origins = {"http://localhost:7070", "http://localhost:8787"}, allowedHeaders = "*",methods = {RequestMethod.GET,RequestMethod.POST})
    @PostMapping("/addcustomer")
    public @ResponseBody Customer addCustomer(@RequestBody Customer customer)
    {
    	return customerService.saveCustomer(customer);
    }
	@CrossOrigin("*")
    @GetMapping("/getallcustomers")
    public List<Customer> getAllCustomers()
    {
    	return customerService.findAllCustomers();
    }
	
	@CrossOrigin("*")
    @GetMapping("/getcustomerbyid/{adharCardNo}")
    public Customer getCustomerById(@PathVariable("adharCardNo") long adharCardNo)
    {
    	return customerService.findByCustomerId(adharCardNo);
    }
	@CrossOrigin("*")
    @PostMapping("/addcustomerstring")
    public @ResponseBody String getCustomerById(@RequestBody String customer) throws JsonProcessingException
    {
		JsonParser springParser = JsonParserFactory.getJsonParser();
		Map<String, Object> map = springParser.parseMap(customer);

		String mapArray[] = new String[map.size()];
		System.out.println("Items found: " + mapArray.length);
		System.out.println(map.get("addresses"));
		
		 
	      ArrayList addressList = (ArrayList) map.get("addresses");
	      Map<String, Object> innerMap;
	      ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
	      for(Object obj : addressList)
	      {
	    	  
	    	  String json = ow.writeValueAsString(obj);
	    	  innerMap= springParser.parseMap(json);
	    	  System.out.println(innerMap.get("doorNo"));
	    	  
	      }
	      
		
		return customer;
    }
	
}
